# `POST /score`: draft JSON contract

## Request

```json
{
  "checklist_version": "v1",
  "mode": "workbook",
  "facility": {
    "name": "Facility Alpha",
    "type": "Critical Infrastructure",
    "region": "Kenya",
    "asset_value_at_risk": 50000000,
    "daily_revenue_at_risk": 120000,
    "downtime_days": 5,
    "criticality_factor": 1.4,
    "historical_incident_factor": 1.0,
    "threat_environment_score": 65,
    "external_accessibility_score": 60,
    "connectivity_exposure_score": 70,
    "domain_weights": { "physical": 0.35, "cyber": 0.35, "operational": 0.3 }
  },
  "ratings": {
    "PHY-PER-01": 3,
    "PHY-PER-02": 3,
    "CYB-VUL-01": null,
    "...": "one entry per check id, 0 to 5, or null if not yet rated"
  },
  "overrides": {
    "perimeter_security": 70
  }
}
```

| Field               | Type                           | Required                 | Notes                                                                               |
| ------------------- | ------------------------------ | ------------------------ | ----------------------------------------------------------------------------------- |
| `checklist_version` | string                         | yes                      | must match a loaded checklist (`v1` today)                                          |
| `mode`              | `"workbook"` or `"corrected"`  | no, default `"workbook"` | `corrected` arrives this week                                                       |
| `facility`          | object                         | yes                      | the Control Center inputs; or send `facility_id` once Ranadeep's database exists |
| `ratings`           | object: check id → 0–5 or null | yes                      | ids in `PHY-PER-01` format; missing ids are treated as unrated                      |
| `overrides`         | object: parameter → 0–100      | no                       | lead-reviewer manual override (workbook "Manual" mode)                              |

---

## Response: `200 OK`

Example below is **real engine output** for Facility Alpha with every check rated 3.

```json
{
  "checklist_version": "v1",
  "mode": "workbook",
  "facility": { "name": "Facility Alpha" },

  "summary": {
    "trs": 40.0,
    "grade": "Moderate",
    "dominant_driver": "Physical"
  },

  "domains": {
    "physical": {
      "control_score": 60.0,
      "risk_score": 40.0,
      "weight": 0.35,
      "parameters": {
        "perimeter_security": 60.0,
        "surveillance_coverage": 60.0,
        "access_control": 60.0,
        "infrastructure_condition": 60.0,
        "guarding_monitoring": 60.0,
        "environmental_geo_risk": 60.0
      }
    },
    "cyber": {
      "control_score": 60.0,
      "risk_score": 40.0,
      "weight": 0.35,
      "parameters": {
        "vulnerability_severity": 60.0,
        "patch_compliance": 60.0,
        "attack_surface_exposure": 60.0,
        "identity_access": 60.0,
        "cloud_security": 60.0,
        "external_risk_rating": 60.0
      }
    },
    "operational": {
      "control_score": 60.0,
      "risk_score": 40.0,
      "weight": 0.3,
      "parameters": {
        "incident_response_time": 60.0,
        "sop_compliance": 60.0,
        "maintenance_discipline": 60.0,
        "workforce_readiness": 60.0,
        "vendor_dependency": 60.0,
        "business_continuity": 60.0
      }
    }
  },

  "financials": {
    "currency": "USD",
    "likelihood": 0.5131,
    "exposure_factor": 0.6525,
    "downtime_cost": 600000.0,
    "estimated_impact": 2100000.91,
    "expected_loss_value": 200878.65
  },

  "guidance": {
    "premium": "Standard pricing with targeted conditions",
    "deductible": "Standard deductible",
    "required_conditions": "IR drills, SOP compliance and BCP testing"
  },

  "completeness": {
    "rated": 107,
    "total": 107,
    "unrated_ids": []
  }
}
```

### Field meanings

| Field                            | Meaning                                                  | Range / format                 |
| -------------------------------- | -------------------------------------------------------- | ------------------------------ |
| `summary.trs`                    | Total Risk Score: weighted risk across 3 domains         | 0–100, higher = riskier        |
| `summary.grade`                  | TRS band: ≥75 Critical, ≥50 High, ≥25 Moderate, else Low | text                           |
| `summary.dominant_driver`        | domain with highest risk score                           | Physical / Cyber / Operational |
| `domains.*.control_score`        | strength of controls                                     | 0–100, higher = better         |
| `domains.*.risk_score`           | 100 − control_score                                      | 0–100, higher = riskier        |
| `domains.*.parameters.*`         | parameter control score                                  | 0–100                          |
| `financials.likelihood`          | probability proxy                                        | 0–1 (show as %)                |
| `financials.exposure_factor`     | exposure from threat, access, connectivity               | 0–1 (show as %)                |
| `financials.downtime_cost`       | daily revenue × downtime days                            | USD                            |
| `financials.estimated_impact`    | asset damage proxy + uplift, × criticality               | USD                            |
| `financials.expected_loss_value` | ELV                                                      | USD                            |
| `guidance.*`                     | underwriting wording from TRS / driver                   | text                           |
| `completeness`                   | how many checks are rated (for a progress bar)           | counts                         |

### Rounding

The engine keeps full precision internally (tests compare to 0.01). The API rounds only for output:
scores to 2 dp, likelihood/exposure to 4 dp, money to 2 dp.

---

## Errors: `422 Unprocessable Entity`

```json
{ "detail": "PHY-PER-01: rating 7 is outside 0-5" }
```

Raised for: unknown check id, rating outside 0–5, unknown mode, domain weights not summing to 1, missing facility fields.

---

## Questions to agree with Nitheesh

1. **Live scoring**: will the screen call `/score` on every rating change? (Fine: the engine runs in milliseconds.) Or only on a "Calculate" button?
2. **Facility**: send the full facility object each time (above), or a `facility_id` once Ranadeep's database is ready?
3. **Partial ratings**: OK to send only the checks rated so far? Unrated checks currently count as 0, as in the workbook (see bug B5), so scores look worse until the checklist is finished. Should the screen show a warning until `completeness.rated == total`?
4. **Nesting**: is `domains.physical.parameters.perimeter_security` easy for the UI, or would a flat list be easier?
5. **Mode toggle**: does the UI need to show workbook vs corrected side by side, or just one?
6. **Labels**: the API returns ids and keys only; the screen takes display text from `checklist_v1.yaml`. Agreed?
