#!/usr/bin/env bash
# One command for GitHub Codespaces: bash start.sh
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/python -m pip install --disable-pip-version-check -q -r requirements.txt
printf '\nYAVA Field Checklist is starting on port 8000.\n'
exec .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}"
