"""Adapter to Prashanth's score_api.md draft, NOT a local TRS implementation.

The real result must come from the team's /score engine. Demo data is marked
DEMO, and partial ratings display as provisional in either mode.
"""
import math
import httpx


class ScoreUnavailable(Exception):
    pass


FACILITY_NUMERIC_KEYS = (
    'asset_value_at_risk', 'daily_revenue_at_risk', 'downtime_days',
    'criticality_factor', 'historical_incident_factor',
    'threat_environment_score', 'external_accessibility_score',
    'connectivity_exposure_score',
)


def build_score_request(asset: dict, answers: dict, check_ids: list[str], version='v1', mode='workbook') -> dict:
    """Produce the precise request shape shared in score_api.md.

    Send every check, with null for unrated. Do not treat absent as a 3 or
    fabricate any facility values. Existing asset fields remain untouched.
    """
    fields = asset['fields']
    for key in ('asset_name', 'facility_type', 'region', *FACILITY_NUMERIC_KEYS,
                'weight_physical', 'weight_cyber', 'weight_operational'):
        if fields.get(key) in ('', None):
            raise ScoreUnavailable(f'Facility input missing: {key}. Update asset setup.')
    try:
        facility = {
            'name': fields['asset_name'], 'type': fields['facility_type'], 'region': fields['region'],
            **{key: float(fields[key]) for key in FACILITY_NUMERIC_KEYS},
            'domain_weights': {
                'physical': float(fields['weight_physical']),
                'cyber': float(fields['weight_cyber']),
                'operational': float(fields['weight_operational']),
            },
        }
    except (TypeError, ValueError) as err:
        raise ScoreUnavailable(f'Facility numeric input invalid: {err}') from err
    if not all(math.isfinite(v) and v >= 0 for key, v in facility.items() if isinstance(v, (float, int))):
        raise ScoreUnavailable('Facility numeric input must be finite and nonnegative')
    if any(not math.isfinite(x) or not 0 <= x <= 1 for x in facility['domain_weights'].values()):
        raise ScoreUnavailable('Domain weights must each be in the 0–1 range')
    if not math.isclose(sum(facility['domain_weights'].values()), 1, abs_tol=1e-5):
        raise ScoreUnavailable('Domain weights must sum to 1.0')
    for key in ('threat_environment_score', 'external_accessibility_score', 'connectivity_exposure_score'):
        if facility[key] > 100:
            raise ScoreUnavailable(f'{key} must be at most 100')
    ratings = {cid: answers.get(cid, {}).get('rating') for cid in check_ids}
    if any(value is not None and (type(value) is not int or not 0 <= value <= 5) for value in ratings.values()):
        raise ScoreUnavailable('Ratings must be integers 0–5 or null')
    return {'checklist_version': version, 'mode': mode, 'facility': facility, 'ratings': ratings}


def get_score(settings, asset: dict, answers: dict, check_ids: list[str], version='v1') -> dict:
    rated = sum(1 for cid in check_ids if answers.get(cid, {}).get('rating') is not None)
    total = len(check_ids)
    provisional = rated < total
    if settings.score_mode == 'stub':
        # Illustrative only; deliberately NOT claimed to reproduce the workbook.
        values = [answers[c]['rating'] for c in check_ids if answers.get(c, {}).get('rating') is not None]
        score = round(100 - 20 * sum(values) / len(values), 2) if values else None
        grade = ('Critical' if score >= 75 else 'High' if score >= 50 else
                 'Moderate' if score >= 25 else 'Low') if score is not None else '—'
        return {'trs': score, 'grade': grade, 'status': 'demo', 'provisional': provisional,
                'label': 'DEMO score only — not the workbook engine; do not use for decisions.',
                'rated': rated, 'total': total,
                'domains': {}, 'financials': {}, 'guidance': {}, 'dominant_driver': None}
    if settings.score_mode != 'real':
        raise ScoreUnavailable('Invalid YAVA_SCORE_MODE setting')
    if not settings.score_api_url:
        raise ScoreUnavailable('Real /score URL not configured')
    request = build_score_request(asset, answers, check_ids, version, 'workbook')
    headers = {'Authorization': f'Bearer {settings.score_api_token}'} if settings.score_api_token else {}
    try:
        response = httpx.post(settings.score_api_url, json=request, headers=headers, timeout=5)
        response.raise_for_status()
        payload = response.json()
    except (httpx.HTTPError, ValueError) as err:
        raise ScoreUnavailable(f'/score request failed: {err}') from err
    if not isinstance(payload, dict):
        raise ScoreUnavailable('Invalid /score response: expected JSON object')
    summary = payload.get('summary')
    completeness = payload.get('completeness')
    if not isinstance(summary, dict) or not isinstance(summary.get('trs'), (float, int)) or not isinstance(summary.get('grade'), str):
        raise ScoreUnavailable('Invalid /score response: missing summary.trs or summary.grade')
    if not isinstance(completeness, dict) or not isinstance(completeness.get('rated'), int) or not isinstance(completeness.get('total'), int):
        raise ScoreUnavailable('Invalid /score response: missing completeness counts')
    if completeness['total'] != total or completeness['rated'] != rated:
        raise ScoreUnavailable('Scoring engine and checklist completeness disagree; check YAML version')
    return {'trs': summary['trs'], 'grade': summary['grade'],
            'dominant_driver': summary.get('dominant_driver'),
            'domains': payload.get('domains', {}), 'financials': payload.get('financials', {}),
            'guidance': payload.get('guidance', {}),
            'rated': completeness['rated'], 'total': completeness['total'],
            'status': 'real', 'provisional': provisional,
            'label': 'Live /score engine result' + (' — provisional while unrated checks count as 0.' if provisional else '')}
