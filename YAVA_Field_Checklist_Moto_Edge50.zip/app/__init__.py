"""YAVA field assessment Stint 1 prototype."""
