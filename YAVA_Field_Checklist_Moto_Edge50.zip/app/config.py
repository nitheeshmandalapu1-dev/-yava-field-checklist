from dataclasses import dataclass
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Settings:
    db_path: Path = ROOT / 'runtime' / 'yava.sqlite3'
    upload_dir: Path = ROOT / 'runtime' / 'uploads'
    checklist_path: Path = ROOT / 'data' / 'checklist_v1.yaml'
    asset_fields_path: Path = ROOT / 'data' / 'asset_fields.score_contract.yaml'
    score_mode: str = 'stub'
    score_api_url: str = ''
    score_api_token: str = ''


def from_environment() -> Settings:
    return Settings(
        db_path=Path(os.getenv('YAVA_DB_PATH', str(ROOT / 'runtime' / 'yava.sqlite3'))),
        upload_dir=Path(os.getenv('YAVA_UPLOAD_DIR', str(ROOT / 'runtime' / 'uploads'))),
        checklist_path=Path(os.getenv('YAVA_CHECKLIST_PATH', str(ROOT / 'data' / 'checklist_v1.yaml'))),
        asset_fields_path=Path(os.getenv('YAVA_ASSET_FIELDS_PATH', str(ROOT / 'data' / 'asset_fields.score_contract.yaml'))),
        score_mode=os.getenv('YAVA_SCORE_MODE', 'stub').lower(),
        score_api_url=os.getenv('YAVA_SCORE_API_URL', ''),
        score_api_token=os.getenv('YAVA_SCORE_API_TOKEN', ''),
    )
