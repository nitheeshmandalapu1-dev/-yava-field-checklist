"""Mobile-first YAVA field checklist, Stint 1.

This is a LOCAL prototype without Ranadeep's login. Do not expose to the public
Internet until the team's authentication, user access rules and CSRF are integrated.
"""
import io
import os
import uuid
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from PIL import Image, ImageOps, UnidentifiedImageError
from pydantic import BaseModel, Field

from .checklists import flatten_checks, load_asset_fields, load_checklist
from .config import Settings, from_environment
from . import db
from .scoring import get_score, ScoreUnavailable

HERE = Path(__file__).parent
TEMPLATES = Jinja2Templates(directory=str(HERE / 'templates'))
MAX_INCOMING_PHOTO = 3_000_000  # client reduces before upload; hard server cap
MAX_PHOTO_SIDE = 1280


class AnswerPayload(BaseModel):
    rating: int | None = Field(default=None, ge=0, le=5)
    evidence: str = Field(default='', max_length=160)
    note: str = Field(default='', max_length=4000)


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or from_environment()
    db.init_db(settings.db_path)
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    app = FastAPI(title='YAVA Field Checklist — Stint 1', docs_url='/api/docs')
    app.state.settings = settings
    app.mount('/static', StaticFiles(directory=str(HERE / 'static')), name='static')

    def content():
        return load_checklist(settings.checklist_path)

    def check_lookup(check_id):
        checklist = content()
        checks = flatten_checks(checklist)
        match = next((c for c in checks if c['id'] == check_id), None)
        if match is None:
            raise HTTPException(404, 'Check not found in checklist.yaml')
        return checklist, checks, match

    def asset_or_404(asset_id):
        asset = db.get_asset(settings.db_path, asset_id)
        if asset is None:
            raise HTTPException(404, 'Asset not found')
        return asset

    def progress(asset_id, checklist=None):
        checklist = checklist or content()
        answers = db.all_answers(settings.db_path, asset_id)
        checks = flatten_checks(checklist)
        done = sum(1 for c in checks
                   if c['id'] in answers and answers[c['id']]['rating'] is not None)
        return {'done': done, 'total': len(checks),
                'percent': round(100 * done / len(checks)) if checks else 0}

    def current_score(asset_id, asset=None, checklist=None):
        asset = asset or asset_or_404(asset_id)
        checklist = checklist or content()
        try:
            return get_score(settings, asset, db.all_answers(settings.db_path, asset_id),
                             [c['id'] for c in flatten_checks(checklist)], checklist.get('version', 'v1'))
        except ScoreUnavailable as err:
            return {'trs': None, 'grade': '—', 'status': 'unavailable', 'provisional': True,
                    'label': f'Score unavailable: {err}', 'domains': {}, 'financials': {}, 'guidance': {}}

    def view(request: Request, filename: str, **context):
        context.setdefault('demo_mode', settings.score_mode == 'stub')
        context.setdefault('htmx_local', (HERE / 'static' / 'htmx.min.js').exists())
        context.setdefault('checklist_demo', 'demo' in settings.checklist_path.name.lower())
        context.setdefault('asset_fields_demo', 'score_contract' in settings.asset_fields_path.name.lower() or 'demo' in settings.asset_fields_path.name.lower())
        return TEMPLATES.TemplateResponse(request=request, name=filename, context=context)

    @app.get('/', include_in_schema=False)
    def homepage():
        return RedirectResponse('/assets', status_code=303)

    @app.get('/health')
    def health():
        return {'status': 'ok', 'checklist_version': content().get('version', 'unversioned'),
                'score_mode': settings.score_mode}

    @app.get('/assets', response_class=HTMLResponse)
    def assets(request: Request):
        checklist = content()
        all_assets = db.list_assets(settings.db_path)
        for asset in all_assets:
            asset['progress'] = progress(asset['id'], checklist)
        return view(request, 'assets.html', assets=all_assets, asset=None,
                    page_name='Assets')

    @app.get('/assets/new', response_class=HTMLResponse)
    def create_asset_page(request: Request, example: bool = False):
        fields = load_asset_fields(settings.asset_fields_path)
        values = {field['key']: str(field.get('default', '')) for field in fields}
        if example:
            # Sample from Prashanth's draft contract; never inserted without a tap.
            values.update({
                'asset_name': 'Facility Alpha (DEMO)',
                'facility_type': 'Critical Infrastructure', 'region': 'Kenya',
                'asset_value_at_risk': '50000000', 'daily_revenue_at_risk': '120000',
                'downtime_days': '5', 'criticality_factor': '1.4',
                'historical_incident_factor': '1.0',
                'threat_environment_score': '65',
                'external_accessibility_score': '60',
                'connectivity_exposure_score': '70',
                'weight_physical': '0.35', 'weight_cyber': '0.35',
                'weight_operational': '0.30',
            })
        return view(request, 'setup.html', asset=None, asset_id=None,
                    fields=fields, values=values, example=example,
                    page_name='Create asset')

    def validate_fields(form, fields):
        values = {}
        for field in fields:
            value = str(form.get(field['key'], '')).strip()
            if field.get('required') and not value:
                raise HTTPException(422, f"Required field missing: {field['label']}")
            if field.get('type') == 'select' and value and value not in field.get('options', []):
                raise HTTPException(422, f"Invalid option for {field['label']}")
            if field.get('type') == 'number' and value:
                try:
                    number = float(value)
                except ValueError:
                    raise HTTPException(422, f"Invalid number for {field['label']}")
                if not __import__('math').isfinite(number):
                    raise HTTPException(422, f"Invalid number for {field['label']}")
                if 'min' in field and number < field['min'] or 'max' in field and number > field['max']:
                    raise HTTPException(422, f"Out of range: {field['label']}")
            if len(value) > 500:
                raise HTTPException(422, f"Field too long: {field['label']}")
            values[field['key']] = value
        return values

    @app.post('/assets/new')
    async def create_asset_post(request: Request):
        values = validate_fields(await request.form(), load_asset_fields(settings.asset_fields_path))
        asset_id = db.upsert_asset(settings.db_path, values)
        return RedirectResponse(f'/assets/{asset_id}/domains', status_code=303)

    @app.get('/assets/{asset_id}/setup', response_class=HTMLResponse)
    def setup(request: Request, asset_id: str):
        asset = asset_or_404(asset_id)
        return view(request, 'setup.html', asset=asset, asset_id=asset_id,
                    fields=load_asset_fields(settings.asset_fields_path),
                    values=asset['fields'], page_name='Asset setup')

    @app.post('/assets/{asset_id}/setup')
    async def update_asset(request: Request, asset_id: str):
        asset_or_404(asset_id)
        values = validate_fields(await request.form(), load_asset_fields(settings.asset_fields_path))
        db.upsert_asset(settings.db_path, values, asset_id)
        return RedirectResponse(f'/assets/{asset_id}/domains', status_code=303)

    @app.get('/assets/{asset_id}/domains', response_class=HTMLResponse)
    def domains(request: Request, asset_id: str):
        asset = asset_or_404(asset_id)
        checklist = content()
        answers = db.all_answers(settings.db_path, asset_id)
        domain_infos = []
        for domain in checklist['domains']:
            checks = domain['checks']
            rated = sum(1 for c in checks if c['id'] in answers and answers[c['id']]['rating'] is not None)
            next_check = next((c['id'] for c in checks if c['id'] not in answers or answers[c['id']]['rating'] is None),
                              checks[0]['id'] if checks else None)
            domain_infos.append({**domain, 'count': len(checks), 'done': rated,
                                 'next_check': next_check})
        return view(request, 'domains.html', asset=asset, asset_id=asset_id,
                    domains=domain_infos, progress=progress(asset_id, checklist), page_name='Domains')

    @app.get('/assets/{asset_id}/checks/{check_id}', response_class=HTMLResponse)
    def check_page(request: Request, asset_id: str, check_id: str):
        asset = asset_or_404(asset_id)
        checklist, checks, check = check_lookup(check_id)
        idx = next(i for i, c in enumerate(checks) if c['id'] == check_id)
        return view(request, 'check.html', asset=asset, asset_id=asset_id, check=check,
                    answer=db.get_answer(settings.db_path, asset_id, check_id),
                    photos=db.get_photos(settings.db_path, asset_id, check_id),
                    index=idx, total=len(checks),
                    prev_id=checks[idx-1]['id'] if idx else None,
                    next_id=checks[idx+1]['id'] if idx < len(checks)-1 else None,
                    evidence_tags=checklist['evidence_tags'], score=current_score(asset_id, asset, checklist),
                    progress=progress(asset_id, checklist), page_name='Inspection check')

    @app.post('/api/assets/{asset_id}/checks/{check_id}')
    def save_answer(asset_id: str, check_id: str, payload: AnswerPayload):
        asset = asset_or_404(asset_id)
        checklist, checks, check = check_lookup(check_id)
        if payload.evidence and payload.evidence not in checklist['evidence_tags']:
            raise HTTPException(422, 'Invalid evidence tag')
        timestamp = db.upsert_answer(settings.db_path, asset_id, check_id,
                                     payload.rating, payload.evidence, payload.note)
        return {'saved': True, 'saved_at': timestamp, 'progress': progress(asset_id, checklist),
                'score': current_score(asset_id, asset, checklist)}

    @app.get('/assets/{asset_id}/score-fragment', response_class=HTMLResponse)
    def score_fragment(request: Request, asset_id: str):
        asset = asset_or_404(asset_id)
        return view(request, '_score.html', asset=asset,
                    score=current_score(asset_id, asset), progress=progress(asset_id))

    @app.get('/assets/{asset_id}/summary', response_class=HTMLResponse)
    def summary(request: Request, asset_id: str):
        asset = asset_or_404(asset_id)
        checklist = content()
        answers = db.all_answers(settings.db_path, asset_id)
        domains = []
        for domain in checklist['domains']:
            items = [{**check, 'answer': answers.get(check['id'])} for check in domain['checks']]
            domains.append({**domain, 'items': items})
        return view(request, 'summary.html', asset=asset, asset_id=asset_id,
                    domains=domains, score=current_score(asset_id, asset, checklist),
                    progress=progress(asset_id, checklist), page_name='Assessment summary')

    @app.post('/api/assets/{asset_id}/checks/{check_id}/photos')
    async def upload_photo(asset_id: str, check_id: str, photo: UploadFile = File(...)):
        asset_or_404(asset_id)
        check_lookup(check_id)
        if photo.content_type not in {'image/jpeg', 'image/png', 'image/webp'}:
            raise HTTPException(415, 'Only JPEG, PNG or WebP photos are accepted')
        incoming = await photo.read(MAX_INCOMING_PHOTO + 1)
        await photo.close()
        if len(incoming) > MAX_INCOMING_PHOTO:
            raise HTTPException(413, 'Photo is too large: compress it before uploading')
        try:
            with Image.open(io.BytesIO(incoming)) as opened:
                if opened.format not in {'JPEG', 'PNG', 'WEBP'}:
                    raise HTTPException(415, 'Invalid image file')
                image = ImageOps.exif_transpose(opened)
                image.thumbnail((MAX_PHOTO_SIDE, MAX_PHOTO_SIDE))
                rgb = image.convert('RGB')
                output = io.BytesIO()
                rgb.save(output, format='JPEG', quality=73, optimize=True)
                thumb = rgb.copy()
                thumb.thumbnail((260, 260))
                thumb_output = io.BytesIO()
                thumb.save(thumb_output, format='JPEG', quality=60, optimize=True)
        except (UnidentifiedImageError, OSError, Image.DecompressionBombError, ValueError) as exc:
            raise HTTPException(415, 'Invalid or unsafe image') from exc
        name = f'{uuid.uuid4().hex}.jpg'
        directory = settings.upload_dir / asset_id
        directory.mkdir(parents=True, exist_ok=True)
        (directory / name).write_bytes(output.getvalue())
        (directory / name.replace('.jpg', '_thumb.jpg')).write_bytes(thumb_output.getvalue())
        photo_id = db.add_photo(settings.db_path, asset_id, check_id, name)
        return {'saved': True, 'photo_id': photo_id, 'url': f'/photos/{photo_id}',
                'bytes': len(output.getvalue())}

    @app.get('/photos/{photo_id}')
    def photo_file(photo_id: str, thumb: bool = False):
        record = db.get_photo(settings.db_path, photo_id)
        if not record:
            raise HTTPException(404, 'Photo not found')
        name = record['filename'].replace('.jpg', '_thumb.jpg') if thumb else record['filename']
        path = settings.upload_dir / record['asset_id'] / name
        if not path.is_file():
            raise HTTPException(404, 'Photo missing on disk')
        return FileResponse(path, media_type='image/jpeg', headers={'Cache-Control': 'private, max-age=300'})

    @app.delete('/api/photos/{photo_id}')
    def remove_photo(photo_id: str):
        record = db.get_photo(settings.db_path, photo_id)
        if not record:
            raise HTTPException(404, 'Photo not found')
        db.delete_photo(settings.db_path, photo_id)
        (settings.upload_dir / record['asset_id'] / record['filename']).unlink(missing_ok=True)
        (settings.upload_dir / record['asset_id'] / record['filename'].replace('.jpg', '_thumb.jpg')).unlink(missing_ok=True)
        return {'deleted': True}

    return app


app = create_app()
