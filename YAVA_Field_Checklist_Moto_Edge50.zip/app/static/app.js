/* YAVA Stint 1: save-on-change with durable browser-side drafts for poor signal.
   Photos require connectivity and are compressed before upload.
   Real login must be integrated before any public deployment. */
(() => {
  'use strict';
  const body = document.body;
  const assetId = body.dataset.assetId;
  const checkId = body.dataset.checkId;
  if (!assetId) return;
  const prefix = `yava:draft:${assetId}:`;
  const form = document.querySelector('#check-form');
  const saveStatus = document.querySelector('#save-status');
  let uploading = false;
  let activeSync = null;
  let noteTimer = null;

  function status(text, type = '') {
    if (!saveStatus) return;
    saveStatus.textContent = text;
    saveStatus.className = 'save-status' + (type ? ` ${type}` : '');
  }

  function pendingKeys() {
    const keys = [];
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(prefix)) keys.push(key);
      }
    } catch (err) { status('Browser drafts unavailable; keep a stable connection.', 'error'); }
    return keys.sort();
  }

  function readPayload() {
    if (!form) return null;
    const selected = form.querySelector('input[name="rating"]:checked');
    return {
      rating: selected ? Number(selected.value) : null,
      evidence: form.querySelector('#evidence').value,
      note: form.querySelector('#note').value
    };
  }

  function storeDraft() {
    if (!checkId) return;
    try {
      localStorage.setItem(prefix + checkId, JSON.stringify(readPayload()));
      status('Saving…', 'pending');
    } catch (err) {
      status('Cannot store a browser draft. Check browser storage.', 'error');
    }
  }

  async function refreshScore() {
    const target = document.querySelector('#score-fragment');
    if (!target) return;
    if (window.htmx && typeof window.htmx.trigger === 'function') {
      window.htmx.trigger(document.body, 'yava:answer-saved');
    } else {
      try {
        const response = await fetch(`/assets/${encodeURIComponent(assetId)}/score-fragment`, { cache: 'no-store' });
        if (response.ok) target.innerHTML = await response.text();
      } catch (err) { /* Scoring is a secondary UI; the draft remains safe. */ }
    }
  }

  // Serialize POSTs so rapid button taps never overwrite a later answer with an earlier one.
  async function syncDrafts() {
    if (activeSync) return activeSync;
    activeSync = (async () => {
      let changed = false;
      for (let attempt = 0; attempt < 25; attempt++) {
        const keys = pendingKeys();
        if (!keys.length) {
          if (changed) await refreshScore();
          if (form) status('✓ All changes saved');
          return true;
        }
        const key = keys[0];
        const raw = localStorage.getItem(key);
        if (!raw) continue;
        try {
          const response = await fetch(`/api/assets/${encodeURIComponent(assetId)}/checks/${encodeURIComponent(key.slice(prefix.length))}`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: raw,
            cache: 'no-store', credentials: 'same-origin'
          });
          if (!response.ok) throw new Error(`Server refused save (HTTP ${response.status}).`);
          if (localStorage.getItem(key) === raw) localStorage.removeItem(key);
          changed = true;
        } catch (err) {
          if (changed) await refreshScore();
          status(navigator.onLine ? `Not saved to server yet: ${err.message}` : 'Offline: saved on this phone, pending sync', 'pending');
          return false;
        }
      }
      // Very rapid input: re-enter on next input/online event to keep the UI responsive.
      if (changed) await refreshScore();
      return true;
    })();
    try { return await activeSync; } finally { activeSync = null; }
  }

  function onChange() { storeDraft(); syncDrafts(); }

  if (form) {
    // Restore any unsent answer before syncing. This also works after a browser restart.
    try {
      const draft = localStorage.getItem(prefix + checkId);
      if (draft) {
        const data = JSON.parse(draft);
        const radio = form.querySelector(`input[name="rating"][value="${data.rating}"]`);
        if (radio) radio.checked = true;
        form.querySelector('#evidence').value = data.evidence || '';
        form.querySelector('#note').value = data.note || '';
        status('Restored a pending draft from this phone', 'pending');
      }
    } catch (err) { status('Could not restore this browser draft.', 'error'); }
    form.querySelectorAll('input[name="rating"]').forEach(input => input.addEventListener('change', onChange));
    form.querySelector('#evidence').addEventListener('change', onChange);
    form.querySelector('#note').addEventListener('input', () => {
      // Write locally immediately on every keystroke; server writes are debounced.
      storeDraft();
      clearTimeout(noteTimer);
      noteTimer = setTimeout(syncDrafts, 450);
    });
  }
  window.addEventListener('online', syncDrafts);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) syncDrafts(); });
  syncDrafts();

  const upload = document.querySelector('#photo-upload');
  async function compress(file) {
    if (file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/webp') {
      throw new Error('Select a JPEG, PNG or WebP image.');
    }
    const objectUrl = URL.createObjectURL(file);
    try {
      const image = new Image();
      await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; image.src = objectUrl; });
      const scale = Math.min(1, 1280 / Math.max(image.width, image.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(image.width * scale);
      canvas.height = Math.round(image.height * scale);
      if (!canvas.width || !canvas.height) throw new Error('Invalid photo dimensions.');
      canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', .72));
      if (!blob) throw new Error('Photo compression failed.');
      return new File([blob], 'evidence.jpg', { type: 'image/jpeg' });
    } finally { URL.revokeObjectURL(objectUrl); }
  }

  function addPhoto(photoId) {
    const gallery = document.querySelector('#photos');
    if (!gallery) return;
    const tile = document.createElement('div'); tile.className = 'photo-tile'; tile.dataset.photoId = photoId;
    const link = document.createElement('a'); link.href = `/photos/${photoId}`; link.target = '_blank'; link.rel = 'noopener';
    const image = document.createElement('img'); image.src = `/photos/${photoId}?thumb=1`; image.alt = 'Inspection evidence photo'; image.loading = 'lazy';
    link.appendChild(image); tile.appendChild(link);
    const button = document.createElement('button'); button.type = 'button'; button.className = 'remove-photo'; button.dataset.photoId = photoId; button.textContent = '×'; button.setAttribute('aria-label', 'Remove photo');
    tile.appendChild(button); gallery.prepend(tile);
  }

  if (upload) upload.addEventListener('change', async () => {
    const file = upload.files && upload.files[0];
    if (!file || uploading) return;
    if (!navigator.onLine) { status('Photo upload needs a connection. Your answers remain saved locally.', 'pending'); upload.value = ''; return; }
    uploading = true; status('Compressing and uploading photo…', 'pending');
    try {
      const optimized = await compress(file);
      const formData = new FormData(); formData.append('photo', optimized, optimized.name);
      const response = await fetch(`/api/assets/${encodeURIComponent(assetId)}/checks/${encodeURIComponent(checkId)}/photos`, { method: 'POST', body: formData });
      if (!response.ok) {
        const detail = await response.json().catch(() => ({}));
        throw new Error(detail.detail || `Upload failed (HTTP ${response.status})`);
      }
      const data = await response.json(); addPhoto(data.photo_id); status('✓ Photo uploaded');
    } catch (err) { status(`Photo not uploaded: ${err.message}`, 'error'); }
    finally { uploading = false; upload.value = ''; }
  });

  document.querySelector('#photos')?.addEventListener('click', async event => {
    const button = event.target.closest('button[data-photo-id]');
    if (!button || !confirm('Remove this evidence photo?')) return;
    try {
      const response = await fetch(`/api/photos/${encodeURIComponent(button.dataset.photoId)}`, { method: 'DELETE' });
      if (!response.ok) throw new Error('Could not delete photo');
      button.closest('.photo-tile').remove(); status('✓ Photo removed');
    } catch (err) { status(`Photo not removed: ${err.message}`, 'error'); }
  });
})();
