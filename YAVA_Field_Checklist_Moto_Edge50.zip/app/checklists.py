"""Read Vinay's original flat checklist_v1.yaml without changing the source.

Also supports the older nested demo fixture so existing screen/QA code still works.
The YAML itself is the single source of truth for IDs, text, guidance and weights.
"""
from collections import OrderedDict
from pathlib import Path
import re
import yaml

# Vinay's file contains no evidence vocabulary; these choices are temporary UI
# defaults drawn from the brief and must be agreed with the team.
PROVISIONAL_EVIDENCE_TAGS = ['Observed', 'Documented', 'Reported']


def load_checklist(path: Path) -> dict:
    with path.open('r', encoding='utf-8') as stream:
        source = yaml.safe_load(stream)
    if isinstance(source, list):
        match = re.search(r'v(\d+)', path.stem, re.IGNORECASE)
        version = f'v{match.group(1)}' if match else 'unversioned'
        domains = OrderedDict()
        for entry in source:
            if not isinstance(entry, dict):
                raise ValueError('Each Vinay YAML entry must be an object')
            domain_id = entry.get('domain')
            if not isinstance(domain_id, str) or not domain_id:
                raise ValueError('Each check must have a domain')
            if domain_id not in domains:
                domains[domain_id] = {'id': domain_id,
                                      'name': domain_id.replace('_', ' ').title(),
                                      'checks': []}
            domains[domain_id]['checks'].append(dict(entry))
        doc = {'version': version, 'domains': list(domains.values()),
               'evidence_tags': PROVISIONAL_EVIDENCE_TAGS.copy()}
    elif isinstance(source, dict):
        doc = source
    else:
        raise ValueError('Checklist must be a list of entries or domains object')
    if not isinstance(doc.get('domains'), list) or not doc['domains']:
        raise ValueError('Checklist must contain domains')
    seen = set()
    for domain in doc['domains']:
        if not domain.get('id') or not domain.get('name') or not isinstance(domain.get('checks'), list):
            raise ValueError('Each domain needs id, name, checks')
        for check in domain['checks']:
            check_id = check.get('id')
            if not isinstance(check_id, str) or not check_id or not check.get('text') or check_id in seen:
                raise ValueError('Check IDs must be unique, and every check needs text')
            seen.add(check_id)
    doc.setdefault('evidence_tags', PROVISIONAL_EVIDENCE_TAGS.copy())
    return doc


def load_asset_fields(path: Path) -> list[dict]:
    with path.open('r', encoding='utf-8') as stream:
        doc = yaml.safe_load(stream)
    fields = doc.get('fields') if isinstance(doc, dict) else None
    if not isinstance(fields, list) or not any(x.get('key') == 'asset_name' for x in fields):
        raise ValueError('Asset field config must include fields and asset_name')
    allowed = {'text', 'date', 'number', 'select', 'textarea'}
    for field in fields:
        if field.get('type') not in allowed or not field.get('key') or not field.get('label'):
            raise ValueError('Invalid asset field specification')
    return fields


def flatten_checks(doc: dict) -> list[dict]:
    return [{**check, 'domain_id': domain['id'], 'domain_name': domain['name']}
            for domain in doc['domains'] for check in domain['checks']]
