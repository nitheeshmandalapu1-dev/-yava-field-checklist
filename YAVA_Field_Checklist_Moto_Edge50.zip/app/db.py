import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


@contextmanager
def connection(path: Path):
    conn = sqlite3.connect(str(path), timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with connection(path) as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS assets (
           id TEXT PRIMARY KEY, data_json TEXT NOT NULL,
           created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS answers (
           asset_id TEXT NOT NULL, check_id TEXT NOT NULL,
           rating INTEGER, evidence TEXT, note TEXT NOT NULL DEFAULT '',
           updated_at TEXT NOT NULL,
           PRIMARY KEY (asset_id, check_id),
           FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS photos (
           id TEXT PRIMARY KEY, asset_id TEXT NOT NULL, check_id TEXT NOT NULL,
           filename TEXT NOT NULL, created_at TEXT NOT NULL,
           FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
        );
        ''')


def parse_asset(row):
    return {**dict(row), 'fields': json.loads(row['data_json'])} if row else None


def list_assets(path: Path):
    with connection(path) as db:
        rows = db.execute('SELECT * FROM assets ORDER BY updated_at DESC').fetchall()
        return [parse_asset(r) for r in rows]


def get_asset(path: Path, asset_id: str):
    with connection(path) as db:
        return parse_asset(db.execute('SELECT * FROM assets WHERE id=?', (asset_id,)).fetchone())


def upsert_asset(path: Path, fields: dict, asset_id: str | None = None) -> str:
    asset_id = asset_id or uuid.uuid4().hex
    timestamp = now()
    with connection(path) as db:
        db.execute('''INSERT INTO assets(id,data_json,created_at,updated_at)
            VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET
            data_json=excluded.data_json, updated_at=excluded.updated_at''',
            (asset_id, json.dumps(fields), timestamp, timestamp))
    return asset_id


def get_answer(path: Path, asset_id: str, check_id: str):
    with connection(path) as db:
        row = db.execute('SELECT * FROM answers WHERE asset_id=? AND check_id=?',
                         (asset_id, check_id)).fetchone()
        return dict(row) if row else {'rating': None, 'evidence': '', 'note': ''}


def all_answers(path: Path, asset_id: str) -> dict:
    with connection(path) as db:
        rows = db.execute('SELECT * FROM answers WHERE asset_id=?', (asset_id,)).fetchall()
        return {r['check_id']: dict(r) for r in rows}


def upsert_answer(path: Path, asset_id: str, check_id: str, rating, evidence, note):
    timestamp = now()
    with connection(path) as db:
        db.execute('''INSERT INTO answers(asset_id,check_id,rating,evidence,note,updated_at)
            VALUES(?,?,?,?,?,?) ON CONFLICT(asset_id,check_id) DO UPDATE SET
            rating=excluded.rating, evidence=excluded.evidence,
            note=excluded.note, updated_at=excluded.updated_at''',
            (asset_id, check_id, rating, evidence, note, timestamp))
        db.execute('UPDATE assets SET updated_at=? WHERE id=?', (timestamp, asset_id))
    return timestamp


def add_photo(path: Path, asset_id: str, check_id: str, filename: str):
    photo_id = uuid.uuid4().hex
    with connection(path) as db:
        db.execute('INSERT INTO photos VALUES (?,?,?,?,?)',
                   (photo_id, asset_id, check_id, filename, now()))
    return photo_id


def get_photo(path: Path, photo_id: str):
    with connection(path) as db:
        row = db.execute('SELECT * FROM photos WHERE id=?', (photo_id,)).fetchone()
        return dict(row) if row else None


def get_photos(path: Path, asset_id: str, check_id: str):
    with connection(path) as db:
        rows = db.execute('SELECT * FROM photos WHERE asset_id=? AND check_id=? ORDER BY created_at DESC',
                          (asset_id, check_id)).fetchall()
        return [dict(row) for row in rows]


def delete_photo(path: Path, photo_id: str):
    with connection(path) as db:
        db.execute('DELETE FROM photos WHERE id=?', (photo_id,))
