# YAVA Field Checklist — start on Motorola Edge 50

**No laptop, Termux or VS Code app needed.** Use **Google Chrome** and **GitHub Codespaces** (a cloud computer). Requires Wi-Fi/mobile data and a GitHub account that has Codespaces access.

## First time — exactly what to tap

1. Download `YAVA_Field_Checklist_Moto_Edge50.zip` from the ChatGPT response. Find it under **Files → Downloads** on your Motorola.
2. Open **Chrome** → https://github.com/new. Sign in to GitHub; create a **Private** repository named `yava-field-checklist`. Tick **Add a README file**, then tap **Create repository**.
3. On the new repository, tap **Code → Codespaces → Create codespace on main**. If the controls are cramped, use Chrome **⋮ → Desktop site** and rotate your phone sideways. This opens the VS Code editor **inside Chrome**.
4. In VS Code's **Explorer** (file list on left), long-press your repository folder (or open its `...` menu) → **Upload...** → choose the downloaded ZIP from Downloads. It uploads as **one file**; do not try to upload each source file.
5. Open **☰ → Terminal → New Terminal** in Codespaces. Paste these commands, **one line at a time**:

   ```bash
   python3 -m zipfile -e YAVA_Field_Checklist_Moto_Edge50.zip .
   bash start.sh
   ```

6. Open the **PORTS** tab in the lower panel, find **8000**, and tap the **globe / Open in Browser** icon. The website will open on your Motorola. Keep port visibility **Private**. The app works at the forwarded address; **127.0.0.1:8000 is not the correct URL on your phone** when using Codespaces.

## Try the complete five-screen flow

1. **Assets** → **+ New asset**.
2. **Asset setup** → **Use sample Facility Alpha details** → **Save and continue** (sample data only).
3. **Domains** → **Physical** → **Open**.
4. **Check** → select rating `3` → evidence `Observed` → enter a note → tap **Add photo** to choose an Android photo or camera image. Verify **All changes saved**; navigate **Next/Back**.
5. **Summary** → see progress, risk grade and TRS (initially **DEMO**, not real engine output). Reopen the browser and return to the asset to verify your rating, note and image remain.

The provided app contains **all 107 real questions** from Vinay's `checklist_v1.yaml`. Do not modify it to invent or omit checks.

## Run automated tests in Codespaces

Stop the server in the terminal with **Ctrl+C** (if your keyboard has no Ctrl button, open a *new* terminal instead). In a terminal run:

```bash
.venv/bin/python -m pytest -q
```

## What is still team-dependent (do NOT claim as completed)

- **Prashanth's actual running `/score` endpoint:** only his draft JSON contract was supplied. UI is wired to that contract, but displays a clearly marked demo score until the real API is reachable and `YAVA_SCORE_MODE=real` is configured.
- **Ranadeep's real authentication and data models:** uploaded files contained FastAPI basic endpoints, tests and Docker configuration, but no functioning login nor database models. This prototype stores data locally in SQLite. Integrate your work inside the shared repo behind real login before any public rollout.
- **Final Control Center field definitions:** the asset setup currently follows Prashanth's draft JSON facility fields. Vinay's YAML contains only checks/weights, not the entire Control Center workbook form.
- **Final phone + slow-3G tests, README and video:** use two real phones, review the page network transfer on a browser with slow-3G throttling, and record the finished application. Slow-3G was not remotely validated here.

**Keep your project private:** the current prototype has no login and must not be made public or used with sensitive real site data. Codespaces persistence is attached to your development environment; commit source code, but do not commit `runtime/` or secrets. No real production deployment is included.

## If you see common problems

- **`No such file: ZIP`**: upload the ZIP into the repository root, not into a child folder. Run `ls` in the terminal to check the file name.
- **`Port 8000` isn't visible**: check that `bash start.sh` is still running and shows `Uvicorn running...`, then open the Ports panel.
- **You see `Score unavailable`**: the running `/score` service has not yet been connected. In demo mode, scores are visibly marked DEMO.
- **A save is pending**: reconnect to the internet and reopen that assessment in the same mobile browser; pending text answer drafts are kept locally and retried. **Photos don't queue offline.**
- **Your GitHub account has no Codespaces access**: ask Ranadeep to add you to the existing shared repository and enable Codespaces or use a laptop. Do not publish an unprotected demo just to access it.
