"""Optional: download and self-host official HTMX for reliable slow-3G operation.
Run once from the project root while you have an Internet connection.
"""
from pathlib import Path
from urllib.request import urlopen

url = 'https://cdnjs.cloudflare.com/ajax/libs/htmx/2.0.7/htmx.min.js'
target = Path(__file__).resolve().parent.parent / 'app' / 'static' / 'htmx.min.js'
with urlopen(url, timeout=20) as response:
    js = response.read()
if not js or len(js) < 10_000 or len(js) > 150_000:
    raise RuntimeError('Unexpected HTMX download size; nothing saved')
target.write_bytes(js)
print(f'Installed HTMX locally: {target} ({len(js)} bytes)')
