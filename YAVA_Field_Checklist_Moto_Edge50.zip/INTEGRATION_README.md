# Team integration checklist (2 November 2026)

This standalone package **already reads Vinay's exact `checklist_v1.yaml`** and builds JSON conforming to Prashanth's supplied `score_api.md` (copy in `docs/`). It is runnable on a Motorola Edge 50 using Codespaces. Start with `MOBILE_START_HERE.md`.

**Vinay:** confirm three provisional evidence tag labels and the complete actual workbook Control Center asset form. YAML question text and weights are unmodified.

**Prashanth:** share a **working reachable `POST /score` endpoint** or mount it in Ranadeep's backend. Tests already verify the JSON contract and response mapping. Unrated checks are sent as null; provisional warning stays until 107/107 rated.

**Ranadeep:** share Git repo and authentication / PostgreSQL models. Please **merge our routes and templates into your shared project**, rather than overwriting your root `app/main.py`. Existing local SQLite data is for isolated prototype testing; use production team ownership rules before shared deployment. Your received repository skeleton only exposed `/` and `/health`.

**Nitheesh:** test the field flow on two phones under slow 3G, verify large tap targets, page transfers, photo compression and resuming after closing Chrome; capture a short screen recording and final README/links; share report on 6 November. Your local workflow is fully usable for a demo, but team integrations remain labelled as pending.
