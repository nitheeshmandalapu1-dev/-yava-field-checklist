# Team integration: exact current status

## Vinay: RECEIVED and integrated
- The original `data/checklist_v1.yaml` (flat list) is **included unmodified**.
- Loader groups it into Physical (36), Cyber (35), Operational (36) without hard-coded questions.
- All 107 IDs, `parameter`, `parameter_weight`, `item_weight`, `text`, `guidance` are preserved.
- The YAML does not specify evidence tag choices or Control Center facility fields. Current evidence choices and `asset_fields.score_contract.yaml` are **provisional** and must be verified against the workbook.

## Prashanth: API contract received; real endpoint PENDING
- Adapter sends `POST /score` JSON according to `score_api.md`:
  `checklist_version`, `mode: workbook`, `facility` (including numerical inputs and domain weights), and `ratings` keyed by each of 107 check IDs, using `null` for unanswered.
- Response reader uses `summary.trs`, `summary.grade`, `summary.dominant_driver`, `domains`, `financials`, `guidance` and `completeness`.
- Incomplete assessments prominently mark TRS provisional (unrated = 0 in workbook mode).
- Choose `YAVA_SCORE_MODE=real` and supply `YAVA_SCORE_API_URL` **only when a working API is available**; otherwise demo scores are clearly labelled and are NOT workbook output.
- Need to confirm contract and error response stability, including scoring behaviour for unanswered items.

## Ranadeep: skeleton received; shared integration PENDING
- His shared FastAPI skeleton exposes only `/` and `/health`; Docker/Compose configure a Postgres service but do **not** yet implement database models or authentication.
- This zip is a standalone ready-to-merge feature. **Do not replace his `app/main.py` outright**: merge routes and templates into the shared repo on your feature branch, coordinating model tables, database session, ownership and CSRF/auth.
- For a private local demonstration this feature continues to use SQLite and is NOT safe for public deployment until authenticated server-side authorization is integrated.

## Manual acceptance required before 6 November
- Validate actual Control Center fields and evidence vocabulary against workbook.
- Verify /score `Facility Alpha` golden case: 107 ratings of 3 -> TRS 40.0, Moderate, ELV 200878.65 (cannot confirm without running engine).
- Complete shared repo merge, Postgres persistence and login.
- Test two phones on slow 3G, measure total page transfer <200KB, check all 44px+ targets, record demo video.
