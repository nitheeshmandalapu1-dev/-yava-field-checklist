# Friday 6 November acceptance checks

Use this as a simple phone-based test list before reporting completion. Tick only after a real test.

- [ ] Asset List opens; create Facility Alpha (DEMO) or a safe test asset
- [ ] Asset Setup has approved real Control Center inputs (await Vinay confirmation)
- [ ] Domains show 36 Physical + 35 Cyber + 36 Operational = **107** checks
- [ ] Every check from Vinay's YAML is present in order (no hardcoded questions)
- [ ] 0–5 rating, evidence tag, note and photo work on phone
- [ ] Back / Next work; one check per page; guidance is one tap away
- [ ] Save-on-change displays success; close/reopen phone browser and resume
- [ ] Text draft survives poor signal; photos compress and upload; thumbnails display
- [ ] Live TRS/grade returned by Prashanth's real `/score` endpoint after each answer
- [ ] Provisional warning visible when fewer than 107 checks are rated
- [ ] Ranadeep's real login protects assets and images; repo integration reviewed
- [ ] Test on **two real phones** with Slow 3G emulation / network throttling
- [ ] Tap targets at least 44 px; **each main HTML page under 200KB** excluding separately fetched images
- [ ] README, code links, short **screen recording** and 6 November report provided

**Important:** Automated Python tests cover backend behavior. Phone UX, slow-3G, final login, real scoring, and video are not automatically completed just because tests pass.
