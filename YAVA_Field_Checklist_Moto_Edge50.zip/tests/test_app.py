from io import BytesIO
from pathlib import Path
from PIL import Image
from fastapi.testclient import TestClient
import pytest

from app.config import Settings, ROOT
from app.main import create_app


@pytest.fixture
def app_client(tmp_path):
    settings = Settings(
        db_path=tmp_path / 'checks.sqlite3', upload_dir=tmp_path / 'uploads',
        checklist_path=ROOT / 'data' / 'checklist.demo.yaml',
        asset_fields_path=ROOT / 'data' / 'asset_fields.demo.yaml',
        score_mode='stub'
    )
    app = create_app(settings)
    with TestClient(app) as client:
        yield client, settings


def create_asset(client):
    resp = client.post('/assets/new', data={
        'asset_name': 'Demo site', 'site': 'Testing yard', 'asset_type': 'Facility',
        'assessor': 'Engineer', 'inspection_date': '2026-10-28'
    }, follow_redirects=False)
    assert resp.status_code == 303
    return resp.headers['location'].split('/')[2]


def test_five_screens_and_resume(app_client):
    client, settings = app_client
    assert client.get('/assets').status_code == 200
    assert client.get('/assets/new').status_code == 200
    asset = create_asset(client)
    assert 'Demo site' in client.get('/assets').text
    assert client.get(f'/assets/{asset}/setup').status_code == 200
    assert 'Perimeter' in client.get(f'/assets/{asset}/domains').text
    check_url = f'/assets/{asset}/checks/PHY-PER-01'
    page = client.get(check_url)
    assert page.status_code == 200
    assert all(x in page.text for x in ('Boundary walls', 'name="rating"', 'Supporting photos', 'Inspection notes'))
    score = client.post(f'/api/assets/{asset}/checks/PHY-PER-01', json={
        'rating': 4, 'evidence': 'Observed', 'note': 'East wall gap, photo pending'
    })
    assert score.status_code == 200
    assert score.json()['progress']['done'] == 1
    assert score.json()['score']['trs'] == 20
    # Data must survive a different request, and even a new app instance.
    second_app = create_app(settings)
    with TestClient(second_app) as another:
        restored = another.get(check_url).text
        assert 'East wall gap, photo pending' in restored
        assert 'value="4" checked' in restored
        summary = another.get(f'/assets/{asset}/summary').text
        assert 'Assessment summary' in summary
        assert '1 rated / 4 total' in summary
        assert '/assets/' + asset + '/score-fragment' in summary


def test_validation_and_no_hard_coded_checks(app_client, tmp_path):
    client, settings = app_client
    asset = create_asset(client)
    url = f'/api/assets/{asset}/checks/PHY-PER-01'
    assert client.post(url, json={'rating': 6}).status_code == 422
    assert client.post(url, json={'rating': 3, 'evidence': 'NotARealTag'}).status_code == 422
    assert client.post(f'/api/assets/{asset}/checks/UNKNOWN', json={'rating': 3}).status_code == 404
    yaml_file = tmp_path / 'other.yaml'
    yaml_file.write_text('''version: fixture\nevidence_tags: [Observed]\ndomains:\n  - id: NEW\n    name: Dynamic domain\n    checks:\n      - id: NEW-01\n        text: This appears only in the replacement YAML\n        guidance: Replaced dynamically\n''')
    new_settings = Settings(db_path=settings.db_path, upload_dir=settings.upload_dir,
                            checklist_path=yaml_file, asset_fields_path=settings.asset_fields_path)
    with TestClient(create_app(new_settings)) as new_client:
        assert 'Dynamic domain' in new_client.get(f'/assets/{asset}/domains').text
        assert 'This appears only in the replacement YAML' in new_client.get(f'/assets/{asset}/checks/NEW-01').text
        assert 'Boundary walls' not in new_client.get(f'/assets/{asset}/summary').text


def test_photo_upload_thumbnail_and_delete(app_client):
    client, _ = app_client
    asset = create_asset(client)
    image = Image.new('RGB', (2000, 1600), 'navy')
    buffer = BytesIO(); image.save(buffer, 'JPEG', quality=90)
    url = f'/api/assets/{asset}/checks/PHY-PER-01/photos'
    resp = client.post(url, files={'photo': ('yard.jpg', buffer.getvalue(), 'image/jpeg')})
    assert resp.status_code == 200, resp.text
    photo_id = resp.json()['photo_id']
    assert client.get(f'/photos/{photo_id}').status_code == 200
    small = client.get(f'/photos/{photo_id}?thumb=true')
    assert small.status_code == 200
    assert len(small.content) < len(client.get(f'/photos/{photo_id}').content)
    assert photo_id in client.get(f'/assets/{asset}/checks/PHY-PER-01').text
    assert client.delete(f'/api/photos/{photo_id}').status_code == 200
    assert client.get(f'/photos/{photo_id}').status_code == 404
    assert client.post(url, files={'photo': ('bad.txt', b'hello', 'text/plain')}).status_code == 415


def test_scoring_unavailable_without_real_team_endpoint(app_client):
    client, settings = app_client
    asset = create_asset(client)
    other = Settings(db_path=settings.db_path, upload_dir=settings.upload_dir,
                     checklist_path=settings.checklist_path,
                     asset_fields_path=settings.asset_fields_path, score_mode='real')
    with TestClient(create_app(other)) as app:
        page = app.get(f'/assets/{asset}/summary')
        assert 'Score unavailable' in page.text
        assert 'DEMO score' not in page.text


def test_tap_targets_and_lightweight_static(app_client):
    client, _ = app_client
    css = client.get('/static/styles.css')
    js = client.get('/static/app.js')
    assert css.status_code == 200 and js.status_code == 200
    assert len(css.content) + len(js.content) < 150_000
    assert 'min-height:46px' in css.text
    assert 'min-height:50px' in css.text
    assert 'localStorage.setItem' in js.text
