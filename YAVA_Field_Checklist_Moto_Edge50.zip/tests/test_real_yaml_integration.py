"""Integration tests based on Vinay's real 107-check YAML and Prashanth's draft contract."""
from collections import Counter
from copy import deepcopy
from unittest.mock import patch

from fastapi.testclient import TestClient
import pytest

from app.checklists import flatten_checks, load_checklist
from app.config import ROOT, Settings
from app.main import create_app
from app.scoring import build_score_request, ScoreUnavailable


@pytest.fixture
def real_client(tmp_path):
    settings = Settings(db_path=tmp_path / 'db.sqlite3', upload_dir=tmp_path / 'uploads',
                        checklist_path=ROOT / 'data/checklist_v1.yaml',
                        asset_fields_path=ROOT / 'data/asset_fields.score_contract.yaml',
                        score_mode='stub')
    with TestClient(create_app(settings)) as client:
        yield client, settings


FACILITY_FIELDS = {
    'asset_name': 'Facility Alpha', 'facility_type': 'Critical Infrastructure', 'region': 'Kenya',
    'asset_value_at_risk': '50000000', 'daily_revenue_at_risk': '120000',
    'downtime_days': '5', 'criticality_factor': '1.4',
    'historical_incident_factor': '1.0', 'threat_environment_score': '65',
    'external_accessibility_score': '60', 'connectivity_exposure_score': '70',
    'weight_physical': '.35', 'weight_cyber': '.35', 'weight_operational': '.3',
}


def make_facility(client):
    r = client.post('/assets/new', data=FACILITY_FIELDS, follow_redirects=False)
    assert r.status_code == 303, r.text
    return r.headers['location'].split('/')[2]


def test_vinay_source_all_107_checks_and_weights():
    doc = load_checklist(ROOT / 'data/checklist_v1.yaml')
    all_checks = flatten_checks(doc)
    assert doc['version'] == 'v1'
    assert len(all_checks) == len({x['id'] for x in all_checks}) == 107
    assert Counter(x['domain_id'] for x in all_checks) == {'physical': 36, 'cyber': 35, 'operational': 36}
    assert len({(x['domain'], x['parameter']) for x in all_checks}) == 18
    assert all(all(key in x for key in ('item_weight', 'parameter_weight', 'text', 'guidance')) for x in all_checks)
    assert all_checks[0]['id'] == 'PHY-PER-01'


def test_real_checklist_all_screens_and_resume(real_client):
    client, settings = real_client
    assert client.get('/health').json()['checklist_version'] == 'v1'
    assert client.get('/assets/new').status_code == 200
    asset = make_facility(client)
    domains = client.get(f'/assets/{asset}/domains')
    assert domains.status_code == 200
    assert '107 checks rated' in domains.text
    assert all(s in domains.text for s in ('Physical', 'Cyber', 'Operational'))
    for check_id in ('PHY-PER-01', 'CYB-VUL-01', 'OPS-INC-01'):
        assert client.get(f'/assets/{asset}/checks/{check_id}').status_code == 200
    rated = client.post(f'/api/assets/{asset}/checks/PHY-PER-01', json={
        'rating': 3, 'evidence': 'Observed', 'note': 'Need wall repair'
    })
    assert rated.status_code == 200, rated.text
    assert rated.json()['progress'] == {'done': 1, 'total': 107, 'percent': 1}
    assert rated.json()['score']['provisional']
    with TestClient(create_app(settings)) as another:
        page = another.get(f'/assets/{asset}/checks/PHY-PER-01')
        assert 'Need wall repair' in page.text
        assert 'value="3" checked' in page.text
        summary = another.get(f'/assets/{asset}/summary')
        assert '1 rated / 107 total' in summary.text
        assert 'Provisional assessment' in summary.text


def test_score_request_matches_prashanth_draft_and_allows_unrated(real_client):
    client, _ = real_client
    asset = make_facility(client)
    from app import db
    from app.checklists import flatten_checks, load_checklist
    from app.config import ROOT
    settings = real_client[1]
    saved_asset = db.get_asset(settings.db_path, asset)
    checks = [item['id'] for item in flatten_checks(load_checklist(ROOT/'data/checklist_v1.yaml'))]
    answers = {'PHY-PER-01': {'rating': 3}, 'CYB-VUL-01': {'rating': None}}
    payload = build_score_request(saved_asset, answers, checks)
    assert set(payload) == {'checklist_version', 'mode', 'facility', 'ratings'}
    assert payload['checklist_version'] == 'v1' and payload['mode'] == 'workbook'
    assert len(payload['ratings']) == 107
    assert payload['ratings']['PHY-PER-01'] == 3
    assert payload['ratings']['CYB-VUL-01'] is None
    assert payload['ratings']['OPS-INC-01'] is None
    assert payload['facility']['name'] == 'Facility Alpha'
    assert payload['facility']['domain_weights'] == {'physical': .35, 'cyber': .35, 'operational': .3}
    assert payload['facility']['asset_value_at_risk'] == 50000000
    with pytest.raises(ScoreUnavailable, match='sum to 1'):
        bad = deepcopy(saved_asset)
        bad['fields']['weight_physical'] = '0.5'
        build_score_request(bad, answers, checks)


def test_real_score_response_nested_mapping_and_provisional(real_client):
    client, settings = real_client
    asset = make_facility(client)
    client.post(f'/api/assets/{asset}/checks/PHY-PER-01', json={'rating': 3})
    real_settings = Settings(db_path=settings.db_path, upload_dir=settings.upload_dir,
                             checklist_path=settings.checklist_path,
                             asset_fields_path=settings.asset_fields_path,
                             score_mode='real', score_api_url='http://score-server/score')
    calls = []

    def fake_score(url, json, headers, timeout):
        calls.append((url, json))
        class Response:
            def raise_for_status(self):
                return None
            def json(self):
                return {
                    'summary': {'trs': 40.0, 'grade': 'Moderate', 'dominant_driver': 'Physical'},
                    'completeness': {'rated': 1, 'total': 107, 'unrated_ids': list(json['ratings'])[1:]},
                    'domains': {'physical': {'risk_score': 40.0}},
                    'financials': {'currency': 'USD', 'expected_loss_value': 200878.65},
                    'guidance': {'premium': 'Standard pricing'},
                }
        return Response()

    with patch('app.scoring.httpx.post', side_effect=fake_score):
        with TestClient(create_app(real_settings)) as real_client2:
            result = real_client2.get(f'/assets/{asset}/summary')
            assert result.status_code == 200
            assert 'Moderate' in result.text
            assert '200878.65' in result.text
            assert 'Provisional assessment' in result.text
            assert calls[-1][0] == 'http://score-server/score'
            assert calls[-1][1]['ratings']['PHY-PER-01'] == 3
            assert len(calls[-1][1]['ratings']) == 107


def test_real_mode_no_endpoint_never_masquerades_as_real(real_client):
    client, settings = real_client
    asset = make_facility(client)
    no_endpoint = Settings(db_path=settings.db_path, upload_dir=settings.upload_dir,
                          checklist_path=settings.checklist_path,
                          asset_fields_path=settings.asset_fields_path, score_mode='real')
    with TestClient(create_app(no_endpoint)) as other:
        assert 'Score unavailable' in other.get(f'/assets/{asset}/summary').text


def test_facility_alpha_one_tap_sample_and_page_weights(real_client):
    client, _ = real_client
    example = client.get('/assets/new?example=true')
    assert example.status_code == 200
    assert 'Facility Alpha (DEMO)' in example.text
    assert '50000000' in example.text
    assert 'Use sample Facility Alpha details' in client.get('/assets/new').text
    asset = make_facility(client)
    pages = ['/assets', f'/assets/{asset}/setup', f'/assets/{asset}/domains',
             f'/assets/{asset}/checks/PHY-PER-01', f'/assets/{asset}/summary']
    for page in pages:
        response = client.get(page)
        assert response.status_code == 200
        assert len(response.content) < 200_000, f'{page} exceeded page-body budget'
    assert 'asset_value_at_risk' not in client.get('/assets').text


def test_real_score_summary_shows_detail_without_faking_results(real_client):
    from unittest.mock import patch
    client, s = real_client
    asset = make_facility(client)
    actual = Settings(db_path=s.db_path, upload_dir=s.upload_dir,
                      checklist_path=s.checklist_path, asset_fields_path=s.asset_fields_path,
                      score_mode='real', score_api_url='http://score-server/score')
    class Response:
        def raise_for_status(self): pass
        def json(self):
            return {'summary':{'trs':40,'grade':'Moderate','dominant_driver':'Physical'},
                    'completeness':{'rated':0,'total':107,'unrated_ids':[]},
                    'domains':{'physical':{'risk_score':40,'control_score':60,
                                          'parameters':{'perimeter_security':60}}},
                    'financials':{'currency':'USD','expected_loss_value':200878.65},
                    'guidance':{'premium':'Standard pricing'}}
    with patch('app.scoring.httpx.post', return_value=Response()):
        with TestClient(create_app(actual)) as other:
            html = other.get(f'/assets/{asset}/summary').text
            assert 'Risk breakdown from scoring engine' in html
            assert 'Perimeter Security' in html
            assert 'Expected Loss Value' in html
            assert 'Standard pricing' in html
