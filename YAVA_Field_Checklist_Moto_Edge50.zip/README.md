# YAVA RIP — Field Checklist (Nitheesh's Stint 1)

**Runnable, mobile-first FastAPI + Jinja2 + HTMX field inspection prototype** with Vinay's **real 107-item `checklist_v1.yaml`** (36 physical, 35 cyber, 36 operational). Source code can be moved into Ranadeep's shared backend after authentication and shared database model are ready. All unverified integrations are openly marked in the UI.

## On a Motorola Edge 50

Read **`MOBILE_START_HERE.md`** first. The easiest path is GitHub Codespaces via Chrome. Upload the ZIP and paste:

```bash
python3 -m zipfile -e YAVA_Field_Checklist_Moto_Edge50.zip .
bash start.sh
```

Use the forwarded **port 8000** URL. Keep its visibility **Private**.

## On a Windows/macOS/Linux computer

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m uvicorn app.main:app --reload --port 8000
```

For Windows PowerShell use `py -m venv .venv` and `.venv\\Scripts\\python.exe` in place of `.venv/bin/python`. Open http://127.0.0.1:8000.

## What's implemented

- Asset list; facility setup; 3 domain selection cards; 107 one-question-per-screen inspections; comprehensive summary.
- Checks use the exact IDs, questions, guidance and weights loaded from Vinay's flat YAML, without hardcoded check content.
- Rating 0–5, provisional evidence tags, notes, phone photo input, Next/Back, progress.
- Save every change to SQLite; retry unsent text answers from browser localStorage under poor signal; reopen/resume; server-side image validation and compression with small thumbnails.
- Payload builder exactly matching Prashanth's draft `POST /score` request: `{checklist_version, mode, facility, ratings}`. **All 107 IDs included**, with JSON `null` for unrated checks.
- When configured for a real endpoint, response parser maps summary, nested domain/parameter scores, financials, guidance and completeness; warns that partial scores may overstate risk. If unavailable, does not pretend to have a real score.
- Clear **DEMO** label on interim scores; backend test suite; readme and manual QA instructions. UI controls are touch-sized.

## Important limitations / team handoff

Prashanth supplied a **draft JSON contract**, not a live API. Ranadeep supplied a FastAPI skeleton, not login or an implemented PostgreSQL access layer. Vinay's YAML supplies check content, but the *confirmed Control Center facility form* was not supplied. Therefore full team integration **cannot** be honestly marked complete. This project is a verified handoff-ready module, not a production login-backed application. Do not expose private inspection data, use this to make actual risk decisions, or deploy publicly without team security integration.

### Score API integration

`app/scoring.py` maps to the attached `score_api.md` draft. For example, once a *reachable* real endpoint exists, use these env vars **before** starting the app:

```bash
export YAVA_SCORE_MODE=real
export YAVA_SCORE_API_URL=https://YOUR-TEAM-SERVICE/score
bash start.sh
```

If a token is needed, set `YAVA_SCORE_API_TOKEN` securely. `YAVA_SCORE_MODE=stub` is the default, distinctly labelled demonstration output. **No invented workbook engine** is built into the app. The UI sends all ratings, saves server-side, and highlights **Provisional** while incomplete.

`data/asset_fields.score_contract.yaml` contains the facility fields from Prashanth's draft contract (not confirmed workbook Control Center fields). To update after receiving Vinay's form, change field config and field-name mapping. The evidence vocabulary is **provisional** (`Observed`, `Documented`, `Reported`) until confirmed.

### Ranadeep repository

Work on a **feature branch** and ask Ranadeep how to include routes under his current app, protect all assets / photos per authenticated user, and connect to PostgreSQL; *do not overwrite his `app/main.py` blindly*. The standalone app uses SQLite `runtime/yava.sqlite3` for its own demo. `runtime/` is gitignored.

### Mobile / slow-3G QA

On **two physical phones**, verify: new asset, all 107 checks appear, rating/evidence/note/photo, Next/Back, restart/reopen/recover, live score after every answer, 44px tap targets, compressed photos, and pages under 200KB **excluding independently fetched photo uploads**. Use Chrome desktop DevTools Network → Slow 3G to measure transfer/latency, or ask a teammate with a laptop to do it. This is not equivalent to merely turning on Android Data Saver.

A short screen recording demonstrating the final team integration is **still to be recorded** by the user. If you have Ranadeep's authentication or Prashanth's service, re-run full tests after merge.

## Tests

```bash
.venv/bin/python -m pytest -q
```

The tests validate real YAML completeness, five screens, save + restart, photo handling, invalid input, score contract, optional real score response, and unavailable-score behavior.

## Project layout

- `app/main.py` — FastAPI UI and API routes
- `app/checklists.py` — Vinay YAML adapter and dynamic labels
- `app/scoring.py` — Prashanth `/score` contract and stub
- `app/db.py` — SQLite persistence, resume, attachments metadata
- `app/templates/` — five Jinja2 screens, score fragment
- `app/static/` — mobile CSS / autosave and photo compression JS
- `data/checklist_v1.yaml` — unchanged Vinay source
- `data/asset_fields.score_contract.yaml` — temporary facility-input mapping
- `tests/` — automated checks
- `MOBILE_START_HERE.md` — mobile Chrome/GitHub Codespaces steps

**Stint dates:** 30 October 2026 first screen milestone; 5 November live scoring target; 6 November 2026 final deliverable target. Report on 30 October and 6 November with links, blockers, support needed, and AI use.
